export const LabelColor: any;
