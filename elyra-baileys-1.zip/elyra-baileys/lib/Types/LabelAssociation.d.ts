export const LabelAssociationType: any;
